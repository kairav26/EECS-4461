/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
A1StarterAudioProcessorEditor::A1StarterAudioProcessorEditor(A1StarterAudioProcessor& p)
	: AudioProcessorEditor(&p), audioProcessor(p)
{
    // Make sure that before the constructor has finished, you've set the
    // editor's size to whatever you need it to be.
    setSize (600, 350);
    
    // these define the parameters of our slider object
    arpSlider.setRange (0.0, 1.0, 0.05);
    arpSlider.setTextValueSuffix (" Speed");
	arpSlider.setValue(0.5);

	// this function adds the slider to the editor
	addAndMakeVisible(&arpSlider);
	arpSlider.addListener(this);

	//parameters for the arpSlider label
	arpSliderLabel.setText("Speed of Arpeggiation:", juce::dontSendNotification);
	arpSliderLabel.setFont(juce::Font(16.0f, juce::Font::plain));
	arpSliderLabel.setColour(juce::Label::textColourId, juce::Colours::red);
	arpSliderLabel.attachToComponent(&arpSlider, true);
	arpSliderLabel.setJustificationType(juce::Justification::centredLeft);
	addAndMakeVisible(&arpSliderLabel);

	//parameters for durationSlider
	durationSlider.setRange(0.50, 4.0, 0.50);
	durationSlider.setValue(1.0);
	durationSlider.setTextValueSuffix(" s");
	addAndMakeVisible(&durationSlider);
	durationSlider.addListener(this);
	
	//changes slider dials to the colour red
	getLookAndFeel().setColour(juce::Slider::thumbColourId, juce::Colours::red);

	//parameters for the durationSlider label
	durationSliderLabel.setText("Note Duration of Last Note:", juce::dontSendNotification);
	durationSliderLabel.attachToComponent(&durationSlider, true);
	durationSliderLabel.setFont(juce::Font(16.0f, juce::Font::plain));
	durationSliderLabel.setColour(juce::Label::textColourId, juce::Colours::red);
	durationSliderLabel.setJustificationType(juce::Justification::centredLeft);
	addAndMakeVisible(&durationSliderLabel);

	//parameters for the arpType combo box
	addAndMakeVisible(&arpType);
	arpType.addItem("Ascending", 1);
	arpType.addItem("Descending", 2);
	arpType.addItem("Non Ascending/Descending Pattern", 3);
	arpType.addItem("Repeated Note Pattern", 4);
	arpType.setSelectedId(1);
	arpType.addListener(this);

	//parameters for the arpType label
	arpTypeLabel.setText("Type of Arpeggiation:", juce::dontSendNotification);
	arpTypeLabel.attachToComponent(&arpType, true);
	arpTypeLabel.setFont(juce::Font(16.0f, juce::Font::plain));
	arpTypeLabel.setColour(juce::Label::textColourId, juce::Colours::red);
	arpTypeLabel.setJustificationType(juce::Justification::centredLeft);
	addAndMakeVisible(&arpTypeLabel);

	//parameters for the octaveNum combo box
	addAndMakeVisible(&octaveNum);
	octaveNum.addItem("1", 1);
	octaveNum.addItem("2", 2);
	octaveNum.addItem("3", 3);
	octaveNum.addItem("4", 4);
	octaveNum.addItem("5", 5);
	octaveNum.addListener(this);

	//parameters for the inputOctave label
	addAndMakeVisible(&inputOctave);
	inputOctave.setText("Number of Octaves to Arpeggiate:", juce::dontSendNotification);
	inputOctave.attachToComponent(&octaveNum, true);
	inputOctave.setFont(juce::Font(16.0f, juce::Font::plain));
	inputOctave.setColour(juce::Label::textColourId, juce::Colours::red);
	inputOctave.setJustificationType(juce::Justification::centredLeft);
    
}

A1StarterAudioProcessorEditor::~A1StarterAudioProcessorEditor()
{
}

//==============================================================================
void A1StarterAudioProcessorEditor::paint (juce::Graphics& g)
{
   // fill the whole window white
    g.fillAll (juce::Colours::black);
 
    // set the current drawing colour to black
    g.setColour (juce::Colours::red);
 
    // set the font size and draw text to the screen
    g.setFont (18.0f);
 
    g.drawFittedText ("Arpeggiator Plug-in", 0, 0, getWidth(), 30, juce::Justification::centred, 1);
}

void A1StarterAudioProcessorEditor::resized()
{
    // This is generally where you'll want to lay out the positions of any
    // subcomponents in your editor..
    // sets the position and size of the slider with arguments (x, y, width, height)
    arpSlider.setBounds (175, 170, getWidth() - 195 , 35);
	octaveNum.setBounds(230, 110, getWidth() - 275, 35);
	arpType.setBounds(150, 40, getWidth() - 200, 35);
	durationSlider.setBounds(190, 230, getWidth() - 210, 35);
	
}

void A1StarterAudioProcessorEditor::sliderValueChanged (juce::Slider* slider)
{
    audioProcessor.arpSpeed = arpSlider.getValue();
	audioProcessor.sliderNoteDuration = durationSlider.getValue();
}


void A1StarterAudioProcessorEditor::comboBoxChanged (juce::ComboBox* combobox)
{
	audioProcessor.arpeggiatorType = arpType.getSelectedId();
	audioProcessor.octave = octaveNum.getSelectedId();

}





