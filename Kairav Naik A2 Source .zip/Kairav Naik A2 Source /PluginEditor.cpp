/*
  ==============================================================================

	This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
A2StarterAudioProcessorEditor::A2StarterAudioProcessorEditor(A2StarterAudioProcessor& p)
	: AudioProcessorEditor(&p), audioProcessor(p)
{
	// Make sure that before the constructor has finished, you've set the
	// editor's size to whatever you need it to be.
	setSize(600, 400);

	intervalSlider.setRange(0.1, 3.0, 0.1);
	intervalSlider.setValue(0.1);
	intervalSlider.setTextValueSuffix(" seconds");
	addAndMakeVisible(&intervalSlider);
	intervalSlider.addListener(this);

	intervalLabel.setText("Delay Time:", juce::dontSendNotification);
	intervalLabel.attachToComponent(&intervalSlider, true);
	intervalLabel.setColour(juce::Label::textColourId, juce::Colours::yellow);
	intervalLabel.setJustificationType(juce::Justification::right);
	addAndMakeVisible(intervalLabel);

	drySlider.setRange(0.0, 1.0, 0.1);
	drySlider.setValue(0.0);
	drySlider.setTextValueSuffix(" %");
	addAndMakeVisible(&drySlider);
	drySlider.addListener(this);

	dryLabel.setText("Dry Level:", juce::dontSendNotification);
	dryLabel.attachToComponent(&drySlider, true);
	dryLabel.setColour(juce::Label::textColourId, juce::Colours::yellow);
	dryLabel.setJustificationType(juce::Justification::right);
	addAndMakeVisible(intervalLabel);

	wetSlider.setRange(0.0, 1.0, 0.1);
	wetSlider.setValue(0.0);
	wetSlider.setTextValueSuffix(" %");
	addAndMakeVisible(&wetSlider);
	wetSlider.addListener(this);

	wetLabel.setText("Wet Level:", juce::dontSendNotification);
	wetLabel.attachToComponent(&wetSlider, true);
	wetLabel.setColour(juce::Label::textColourId, juce::Colours::yellow);
	wetLabel.setJustificationType(juce::Justification::right);
	addAndMakeVisible(intervalLabel);

	feedbackSlider.setRange(0.0, 1.0, 0.1);
	feedbackSlider.setValue(0.0);
	feedbackSlider.setTextValueSuffix(" %");
	addAndMakeVisible(&feedbackSlider);
	feedbackSlider.addListener(this);

	feedbackLabel.setText("Feedback Level:", juce::dontSendNotification);
	feedbackLabel.attachToComponent(&feedbackSlider, true);
	feedbackLabel.setColour(juce::Label::textColourId, juce::Colours::yellow);
	feedbackLabel.setJustificationType(juce::Justification::right);
	addAndMakeVisible(feedbackLabel);

	getLookAndFeel().setColour(juce::Slider::thumbColourId, juce::Colours::yellow);

	addAndMakeVisible(&pingPongButton);
	pingPongButton.addListener(this);
	pingPongButton.addItem("Ping Pong Off", 1);
	pingPongButton.addItem("Ping Pong On", 2);
	pingPongButton.setSelectedId(1);

	pingPongLabel.setText("Ping Pong Delay:", juce::dontSendNotification);
	pingPongLabel.attachToComponent(&pingPongButton, true);
	pingPongLabel.setColour(juce::Label::textColourId, juce::Colours::yellow);
	pingPongLabel.setJustificationType(juce::Justification::right);
	addAndMakeVisible(pingPongLabel);

	
}

A2StarterAudioProcessorEditor::~A2StarterAudioProcessorEditor()
{
}

//==============================================================================
void A2StarterAudioProcessorEditor::paint(juce::Graphics& g)
{
	// fill the whole window white
	g.fillAll(juce::Colours::mediumpurple);

	// set the current drawing colour to black
	g.setColour(juce::Colours::yellow);

	// set the font size and draw text to the screen
	g.setFont(18.0f);

	g.drawFittedText("Delay Plugin", 0, 0, getWidth(), 30, juce::Justification::centred, 1);
}

void A2StarterAudioProcessorEditor::resized()
{
	// This is generally where you'll want to lay out the positions of any
	// subcomponents in your editor..
	// sets the position and size of the slider with arguments (x, y, width, height)
	intervalSlider.setBounds(100, 40, getWidth() - 130, 75);
	drySlider.setBounds(100, 90, getWidth() - 130, 75);
	wetSlider.setBounds(100, 140, getWidth() - 130, 75);
	feedbackSlider.setBounds(100, 190, getWidth() - 130, 75);
	pingPongButton.setBounds(150, 270, getWidth() - 180, 35);
	
}

void A2StarterAudioProcessorEditor::sliderValueChanged(juce::Slider* slider)
{
	audioProcessor.timeInterval = intervalSlider.getValue();
	audioProcessor.dryMix = drySlider.getValue();
	audioProcessor.wetMix = wetSlider.getValue();
	audioProcessor.feedbackMix = feedbackSlider.getValue();
}

void A2StarterAudioProcessorEditor::comboBoxChanged(juce::ComboBox* combobox)
{
	audioProcessor.pingPong = pingPongButton.getSelectedId();
}
