/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin processor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
A2StarterAudioProcessor::A2StarterAudioProcessor()
#ifndef JucePlugin_PreferredChannelConfigurations
     : AudioProcessor (BusesProperties()
                     #if ! JucePlugin_IsMidiEffect
                      #if ! JucePlugin_IsSynth
                       .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                      #endif
                       .withOutput ("Output", juce::AudioChannelSet::stereo(), true)
                     #endif
                       )
#endif
{
}

A2StarterAudioProcessor::~A2StarterAudioProcessor()
{
}

//==============================================================================
const juce::String A2StarterAudioProcessor::getName() const
{
    return JucePlugin_Name;
}

bool A2StarterAudioProcessor::acceptsMidi() const
{
   #if JucePlugin_WantsMidiInput
    return true;
   #else
    return false;
   #endif
}

bool A2StarterAudioProcessor::producesMidi() const
{
   #if JucePlugin_ProducesMidiOutput
    return true;
   #else
    return false;
   #endif
}

bool A2StarterAudioProcessor::isMidiEffect() const
{
   #if JucePlugin_IsMidiEffect
    return true;
   #else
    return false;
   #endif
}

double A2StarterAudioProcessor::getTailLengthSeconds() const
{
    return 0.0;
}

int A2StarterAudioProcessor::getNumPrograms()
{
    return 1;   // NB: some hosts don't cope very well if you tell them there are 0 programs,
                // so this should be at least 1, even if you're not really implementing programs.
}

int A2StarterAudioProcessor::getCurrentProgram()
{
    return 0;
}

void A2StarterAudioProcessor::setCurrentProgram (int index)
{
}

const juce::String A2StarterAudioProcessor::getProgramName (int index)
{
    return {};
}

void A2StarterAudioProcessor::changeProgramName (int index, const juce::String& newName)
{
}

//==============================================================================
void A2StarterAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    rate = static_cast<float> (sampleRate);

	timeInterval = 0.0;
	dryMix = 0;
	wetMix = 0.0;
	feedbackMix = 0.0;
	delayWritePosition = 0;
	delayReadPosition = 0;
    // Need to change this value to a number that corresponds to 3 seconds
    delayBufferLength = 3 * (sampleRate);

    delayBuffer.setSize(2, delayBufferLength);
    delayBuffer.clear();

	delayBufferLeftLength = 3 * (sampleRate);
	delayBufferLeft.setSize(1, delayBufferLeftLength);
	delayBufferLeft.clear();

	delayBufferRightLength = 3 * (sampleRate);
	delayBufferRight.setSize(1, delayBufferLeftLength);
	delayBufferRight.clear();

	
}

void A2StarterAudioProcessor::releaseResources()
{
    // When playback stops, you can use this as an opportunity to free up any
    // spare memory, etc.
}

#ifndef JucePlugin_PreferredChannelConfigurations
bool A2StarterAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
  #if JucePlugin_IsMidiEffect
    juce::ignoreUnused (layouts);
    return true;
  #else
    // This is the place where you check if the layout is supported.
    // In this template code we only support mono or stereo.
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
     && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    // This checks if the input layout matches the output layout
   #if ! JucePlugin_IsSynth
    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;
   #endif

    return true;
  #endif
}
#endif

void A2StarterAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
	juce::ScopedNoDenormals noDenormals;
	auto totalNumInputChannels = getTotalNumInputChannels();
	auto totalNumOutputChannels = getTotalNumOutputChannels();
	const int numSamples = buffer.getNumSamples();

	delayReadPosition = static_cast<int>(delayWritePosition - (timeInterval * getSampleRate()) + delayBufferLength)
		% delayBufferLength;
	
	for (int channel = 0; channel < totalNumInputChannels; ++channel) {

		float* channelData = buffer.getWritePointer(channel);
		float* delayData = delayBuffer.getWritePointer(channel, delayBuffer.getNumChannels() - 1);

		float* leftChannelData = buffer.getWritePointer(0);
		float* rightChannelData = buffer.getWritePointer(1);
		float* delayLeftData = delayBuffer.getWritePointer(0);
		float* delayRightData = delayBuffer.getWritePointer(1);

		delayRead = delayReadPosition;
		delayWrite = delayWritePosition;

		for (int i = 0; i < numSamples; ++i) {
			
			if (pingPong == 2)
			{
				const float leftIn = leftChannelData[i];
				const float rightIn = rightChannelData[i];

				float delayOutLeft = delayLeftData[delayRead];
				float delayOutRight = delayRightData[delayRead];

				float delayInputLeft = leftIn + delayOutRight * feedbackMix;
				float delayInputRight = rightIn + delayOutLeft * feedbackMix;

				delayLeftData[delayWrite] = delayInputLeft;
				delayRightData[delayWrite] = delayInputRight;

				float leftOut = leftIn * dryMix + delayOutLeft * wetMix;
				float rightOut = rightIn * dryMix + delayOutRight * wetMix;

				leftChannelData[i] = leftOut;
				rightChannelData[i] = rightOut;

				if (++delayRead >= delayBufferLength) delayRead = 0;
				if (++delayWrite >= delayBufferLength) delayWrite = 0;
			}

			else 
			{
				const float in = channelData[i];

				float out = (dryMix * in + wetMix * delayData[delayRead]);

				delayData[delayWrite] = in + (delayData[delayRead] * feedbackMix);

				channelData[i] = out;

				if (++delayRead >= delayBufferLength) delayRead = 0;
				if (++delayWrite >= delayBufferLength) delayWrite = 0;

				
			}
		}	
	}
	
	delayReadPosition = delayRead;
	delayWritePosition = delayWrite;

	// In case we have more outputs than inputs, this code clears any output
	// channels that didn't contain input data, (because these aren't
	// guaranteed to be empty - they may contain garbage).
	// I've added this to avoid people getting screaming feedback
	// when they first compile the plugin, but obviously you don't need to
	// this code if your algorithm already fills all the output channels.
	//for (int i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
		//buffer.clear(i, 0, buffer.getNumSamples());
}


//==============================================================================
bool A2StarterAudioProcessor::hasEditor() const
{
    return true; // (change this to false if you choose to not supply an editor)
}

juce::AudioProcessorEditor* A2StarterAudioProcessor::createEditor()
{
    return new A2StarterAudioProcessorEditor (*this);
}

//==============================================================================
void A2StarterAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    // You should use this method to store your parameters in the memory block.
    // You could do that either as raw data, or use the XML or ValueTree classes
    // as intermediaries to make it easy to save and load complex data.
}

void A2StarterAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    // You should use this method to restore your parameters from this memory block,
    // whose contents will have been created by the getStateInformation() call.
}

//==============================================================================
// This creates new instances of the plugin..
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new A2StarterAudioProcessor();
}
